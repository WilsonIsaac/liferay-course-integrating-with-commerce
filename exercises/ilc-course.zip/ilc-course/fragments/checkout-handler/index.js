(function() {
    const BUTTON_ID_PREFIX = '_com_liferay_commerce_checkout_web_internal_portlet_CommerceCheckoutPortlet_continue';
    
    let oAuth2Client;
    try {
        console.log("[ERP Interceptor] Initializing OAuth2 Client for: liferay-clarity-etc-spring-boot-oaua");
        oAuth2Client = Liferay.OAuth2Client.FromUserAgentApplication(
            'liferay-clarity-etc-spring-boot-oaua'
        );
    } catch (error) {
        console.error("[ERP Interceptor] OAuth2 Client Initialization Failed:", error);
    }

    /**
     * Extracts the order ID from the <span class="order-id"> element.
     * @returns {string|null}
     */
    function getOrderId() {
        const orderIdElement = document.querySelector('span.order-id');
        const orderId = orderIdElement ? orderIdElement.innerText.trim() : null;
        console.log("[ERP Interceptor] Extracted Order ID:", orderId);
        return orderId;
    }

    /**
     * Extracts the total value from the <div class="commerce-value"> element.
     * Updated to handle nested structures within .autofit-col if necessary.
     * @returns {string|null}
     */
    function getTotalValue() {
        const valueElement = document.querySelector('.autofit-col .commerce-value') || document.querySelector('.commerce-value');
        const totalValue = valueElement ? valueElement.innerText.trim() : null;
        console.log("[ERP Interceptor] Extracted Total Value:", totalValue);
        return totalValue;
    }

    async function callErpOperations() {
        const orderId = getOrderId();
        const totalValue = getTotalValue();
        
        // Base URL
        let url = 'http://localhost:58081/erp/operations';

        /**
         * Updated to RESTful path parameters: /erp/operations/{orderId}/{totalValue}
         * We encode the components to handle special characters (like the '$' in the total value).
         */
        if (orderId && totalValue) {
            url += `/${encodeURIComponent(orderId)}/${encodeURIComponent(totalValue)}`;
        } else if (orderId) {
            url += `/${encodeURIComponent(orderId)}`;
        }

        if (!oAuth2Client) {
            console.warn("[ERP Interceptor] Aborting: oAuth2Client is undefined.");
            return { status: 500, data: null };
        }

        try {
            console.log("[ERP Interceptor] Sending request to:", url);
            
            const response = await oAuth2Client.fetch(url, {
                method: 'GET'
            });

            console.log(`[ERP Interceptor] Received Response - Status: ${response.status} (${response.statusText})`);

            const data = await response.text();
            console.log("[ERP Interceptor] Response Body Content:", data);
            
            return {
                status: response.status,
                data: data
            };
        } catch (error) {
            console.error("[ERP Interceptor] Network or Fetch Error:", error);
            return { status: 503, data: null };
        }
    }

    async function isFormValid() {
        console.log("[ERP Interceptor] Starting validation check...");
        const erpResponse = await callErpOperations();
        
        const isStatusOk = erpResponse.status === 200;

        if (!isStatusOk) {
            console.log(`[ERP Interceptor] Validation Result -> Status OK: ${isStatusOk}, Data: ${erpResponse.data}`);
        }
        
        const finalResult = isStatusOk;
        console.log(`[ERP Interceptor] Overall Validation: ${finalResult ? "PASSED" : "FAILED"}`);
        
        return finalResult;
    }

    function handleErrorUI(button, show) {
        let errorEl = document.getElementById('custom-checkout-error-msg');
        
        if (show) {
            if (!errorEl) {
                errorEl = document.createElement('div');
                errorEl.id = 'custom-checkout-error-msg';
                errorEl.className = 'alert alert-danger';
                errorEl.style.marginTop = '10px';
                errorEl.innerText = 'Validation could not be completed. Please contact your Clarity Account Representative.';
                button.parentNode.insertBefore(errorEl, button.nextSibling);
            }
            button.classList.add('border', 'border-danger');
            errorEl.style.display = 'block';
        } else if (errorEl) {
            errorEl.style.display = 'none';
            button.classList.remove('border', 'border-danger');
        }
    }

    function initInterceptor() {
        const checkoutBtn = document.querySelector('[id^="' + BUTTON_ID_PREFIX + '"]');

        if (!checkoutBtn) {
            console.log("[ERP Interceptor] Checkout button not found on this page.");
            return;
        }

        console.log("[ERP Interceptor] Interceptor attached to checkout button.");

        let validationInProgress = false;

        checkoutBtn.addEventListener('click', async function(event) {
            const activeStepElement = document.querySelector('li.active .multi-step-icon[data-multi-step-icon]');
            const stepIcon = activeStepElement ? activeStepElement.getAttribute('data-multi-step-icon') : null;
            
            console.log("[ERP Interceptor] Detected active step: " + stepIcon);

            if (stepIcon !== "2") {
                console.log("[ERP Interceptor] Active step is not 2. Proceeding with default behavior.");
                return;
            }

            if (validationInProgress) {
                return;
            }

            console.log("[ERP Interceptor] Step 2 active. Intercepting checkout click...");
            
            event.preventDefault();
            event.stopPropagation();

            handleErrorUI(checkoutBtn, false);

            const valid = await isFormValid();

            if (valid) {
                console.log("[ERP Interceptor] Validation successful. Submitting form.");
                
                validationInProgress = true;

                const form = checkoutBtn.closest('form');
                if (form) {
                    form.submit();
                } else {
                    checkoutBtn.click();
                }
            } else {
                console.warn("[ERP Interceptor] Validation failed. Blocking navigation.");
                handleErrorUI(checkoutBtn, true);
                validationInProgress = false;
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initInterceptor);
    } else {
        initInterceptor();
    }
})();